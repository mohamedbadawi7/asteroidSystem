To run this code, the marker needs to open the HelloApplication class in this folder and run it. The marker should see that the Space view
comes up and they are able to perform the functions specified in the assignment description.I believe all the parts of the assignment are
functioning correctly.